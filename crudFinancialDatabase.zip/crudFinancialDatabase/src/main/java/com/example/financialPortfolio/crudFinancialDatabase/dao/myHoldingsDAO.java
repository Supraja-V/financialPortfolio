package com.example.financialPortfolio.crudFinancialDatabase.dao;


import com.example.financialPortfolio.crudFinancialDatabase.entity.myHoldings;

import java.util.List;

public interface myHoldingsDAO {

    public myHoldings save(myHoldings holding);

    public List<myHoldings> read(String name);
}
