package com.example.financialPortfolio.crudFinancialDatabase.entity;


import jakarta.persistence.*;

@Entity
@Table(name="myholdings")
public class myHoldings {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Override
    public String toString() {
        return "myHoldings{" +
                "id=" + id +
                ", ticker='" + ticker + '\'' +
                ", holdingName='" + holdingName + '\'' +
                ", volume=" + volume +
                ", type='" + type + '\'' +
                '}';
    }

    public myHoldings(String ticker, String holdingName, int volume, String type) {
        this.ticker = ticker;
        this.holdingName = holdingName;
        this.volume = volume;
        this.type = type;
    }

    public myHoldings(){

    }

    public int getId() {

        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getTicker() {
        return ticker;
    }

    public void setTicker(String ticker) {
        this.ticker = ticker;
    }

    public String getHoldingName() {
        return holdingName;
    }

    public void setHoldingName(String holdingName) {
        this.holdingName = holdingName;
    }

    public int getVolume() {
        return volume;
    }

    public void setVolume(Integer volume) {
        this.volume = volume;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    private String ticker;

    @Column(name = "holdingName")
    private String holdingName;

    private Integer volume;

    private String type;



}
