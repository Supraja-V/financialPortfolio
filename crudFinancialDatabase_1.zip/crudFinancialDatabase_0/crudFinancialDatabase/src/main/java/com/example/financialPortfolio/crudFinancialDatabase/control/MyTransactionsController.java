package com.example.financialPortfolio.crudFinancialDatabase.control;

import com.example.financialPortfolio.crudFinancialDatabase.dao.myTransactionsDAO;
import com.example.financialPortfolio.crudFinancialDatabase.dao.myTransactionsDAOImpl;
import com.example.financialPortfolio.crudFinancialDatabase.entity.myTransactions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RequestMapping("/api/transactions")
@RestController
public class MyTransactionsController {
//    @Autowired
//    private myTransactionsDAOImpl myTransactionsService;
//
//    @GetMapping("/api/transactions/{ticker}")
//    public List<myTransactions> getTransactions(@PathVariable String ticker) {
//        return myTransactionsService.getTransactionsByTicker(ticker);
//    }

    private myTransactionsDAO transactionsDAO;

    public MyTransactionsController(myTransactionsDAO transactionsDAO) {
        this.transactionsDAO = transactionsDAO;
    }

    @Autowired
    private myTransactionsDAOImpl myTransactionssService;

    @GetMapping
    public List<myTransactions> getAllTransactions() {
        return myTransactionssService.findAll();
    }

    @GetMapping("/{transactionId}")
    public Optional<myTransactions> getTransactionById(@PathVariable Integer transactionId) {
        return Optional.ofNullable(myTransactionssService.findById(transactionId).orElse(null));
    }

    @PostMapping
    public myTransactions createTransaction(@RequestBody myTransactions myTransactions) {
        return myTransactionssService.saveTransaction(myTransactions);
    }

    @PutMapping("/{transactionId}")
    public myTransactions updateTransaction(@PathVariable Integer transactionId, @RequestBody myTransactions myTransactions) {
        myTransactions.setTransaction_id(transactionId);
        return myTransactionssService.saveTransaction(myTransactions);
    }

    @DeleteMapping("/{transactionId}")
    public void deleteTransaction(@PathVariable Integer transactionId) {
        myTransactionssService.deleteById(transactionId);
    }

    @GetMapping("/ticker/{ticker}")
    public List<myTransactions> getTransactionsByTicker(@PathVariable String ticker) {
        return myTransactionssService.findByTicker(ticker);
    }

    @GetMapping("/type/{type}")
    public List<myTransactions> getTransactionsByType(@PathVariable String type) {
        return myTransactionssService.findByType(type);
    }
}
