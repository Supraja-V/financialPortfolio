package com.example.financialPortfolio.crudFinancialDatabase.repository;

import com.example.financialPortfolio.crudFinancialDatabase.entity.myHoldings;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface holdingsRepository extends JpaRepository<myHoldings,Integer> {
    List<myHoldings> findByTicker(String ticker);
    myHoldings findById(Long id);
}
