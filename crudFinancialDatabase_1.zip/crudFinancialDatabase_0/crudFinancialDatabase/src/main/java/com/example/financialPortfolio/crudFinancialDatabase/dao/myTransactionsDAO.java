package com.example.financialPortfolio.crudFinancialDatabase.dao;

import com.example.financialPortfolio.crudFinancialDatabase.entity.myTransactions;

import java.util.Date;
import java.util.List;
import java.util.Optional;

public interface myTransactionsDAO {
    public List<myTransactions> findAll();
    public Optional<myTransactions> findById(Integer transactionId);
    public myTransactions saveTransaction(myTransactions myTransactions);
    public void deleteById(Integer transactionId);
    public List<myTransactions> findByTicker(String ticker);
    public List<myTransactions> findByType(String type);

}
