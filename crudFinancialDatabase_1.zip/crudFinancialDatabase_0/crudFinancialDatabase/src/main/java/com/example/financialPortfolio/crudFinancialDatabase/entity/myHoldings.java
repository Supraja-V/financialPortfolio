package com.example.financialPortfolio.crudFinancialDatabase.entity;


import jakarta.persistence.*;

@Entity
@Table(name="myholdings")
public class myHoldings {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    private String ticker;

    private Float invested_amount;

    private Float avg_cost;

    @Override
    public String toString() {
        return "myHoldings{" +
                "id=" + id +
                ", ticker='" + ticker + '\'' +
                ", invested_amount=" + invested_amount +
                ", avg_cost=" + avg_cost +
                ", volume=" + volume +
                '}';
    }

    public myHoldings() {
    }

    public Integer getId() {
        return id;
    }

    public myHoldings(String ticker, Float invested_amount, Float avg_cost, Integer volume) {
        this.ticker = ticker;
        this.invested_amount = invested_amount;
        this.avg_cost = avg_cost;
        this.volume = volume;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getTicker() {
        return ticker;
    }

    public void setTicker(String ticker) {
        this.ticker = ticker;
    }

    public Float getInvested_amount() {
        return invested_amount;
    }

    public void setInvested_amount(Float invested_amount) {
        this.invested_amount = invested_amount;
    }

    public Float getAvg_cost() {
        return avg_cost;
    }

    public void setAvg_cost(Float avg_cost) {
        this.avg_cost = avg_cost;
    }

    public Integer getVolume() {
        return volume;
    }

    public void setVolume(Integer volume) {
        this.volume = volume;
    }

    private Integer volume;


}
