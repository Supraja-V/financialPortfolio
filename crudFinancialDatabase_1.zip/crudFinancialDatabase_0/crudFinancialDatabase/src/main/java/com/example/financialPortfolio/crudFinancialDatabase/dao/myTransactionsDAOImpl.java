package com.example.financialPortfolio.crudFinancialDatabase.dao;

import com.example.financialPortfolio.crudFinancialDatabase.entity.myTransactions;
import com.example.financialPortfolio.crudFinancialDatabase.repository.transactionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;
import java.util.Optional;

@Service
public class myTransactionsDAOImpl implements myTransactionsDAO {

//    @Autowired
//    private transactionRepository myTransactionRepository;
//
//    @Override
//    public List<myTransactions> getTransactionsByTicker(String ticker) {
//        return myTransactionRepository.findByTicker(ticker);
//    }

    private transactionRepository mytransactionRepository;

    public myTransactionsDAOImpl(transactionRepository transactionRepo){
        this.mytransactionRepository = transactionRepo;
    }

    public List<myTransactions> findAll() {
        return mytransactionRepository.findAll();
    }

    public Optional<myTransactions> findById(Integer transactionId) {
        return mytransactionRepository.findById(transactionId);
    }

    public myTransactions saveTransaction(myTransactions myTransactions) {
        return mytransactionRepository.save(myTransactions);
    }

    public void deleteById(Integer transactionId) {
        mytransactionRepository.deleteById(transactionId);
    }

    public List<myTransactions> findByTicker(String ticker) {
        return mytransactionRepository.findByTicker(ticker);
    }


    public List<myTransactions> findByType(String type) {
        return mytransactionRepository.findByType(type);
    }

}
