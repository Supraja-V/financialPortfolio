package com.example.financialPortfolio.crudFinancialDatabase.dao;


import com.example.financialPortfolio.crudFinancialDatabase.entity.myHoldings;

import java.util.List;
import java.util.Optional;

public interface myHoldingsDAO {

    public List<myHoldings> getAllHoldings();
    public Optional<myHoldings> getHoldingById(Integer id);
    public List<myHoldings> getHoldingsByTicker(String ticker);
    public myHoldings saveHolding(myHoldings holding);
    public void deleteHolding(Integer id);

}
