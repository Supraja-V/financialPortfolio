package com.example.financialPortfolio.crudFinancialDatabase.repository;

import com.example.financialPortfolio.crudFinancialDatabase.entity.myTransactions;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Date;
import java.util.List;
import java.util.Optional;

public interface transactionRepository extends JpaRepository<myTransactions,Integer> {
    List<myTransactions> findByTicker(String ticker);
    List<myTransactions> findByType(String type);
    Optional<myTransactions> findById(Integer id);
}
