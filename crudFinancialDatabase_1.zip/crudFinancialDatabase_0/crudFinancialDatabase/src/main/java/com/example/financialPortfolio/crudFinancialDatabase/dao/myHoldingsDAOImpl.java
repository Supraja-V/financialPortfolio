package com.example.financialPortfolio.crudFinancialDatabase.dao;

import com.example.financialPortfolio.crudFinancialDatabase.entity.myHoldings;
import com.example.financialPortfolio.crudFinancialDatabase.repository.holdingsRepository;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class myHoldingsDAOImpl implements myHoldingsDAO{

//    public myHoldingsDAOImpl(holdingsRepository holdingsRepo){
//        this.holdingsRepo = holdingsRepo;
//    }
//
//    @Autowired
//    private holdingsRepository myHoldingsRepo;
//    @Override
//    public List<myHoldings> getAllHoldings() {
//        return myHoldingsRepo.findAll();
//    }
private holdingsRepository holdingsRepo;

    public myHoldingsDAOImpl(holdingsRepository holdingsRepo){
        this.holdingsRepo = holdingsRepo;
    }
    @Override
    @Transactional
    public List<myHoldings> getAllHoldings() {
        return holdingsRepo.findAll();
    }

    public Optional<myHoldings> getHoldingById(Integer id) {
        return holdingsRepo.findById(id);
    }

    public List<myHoldings> getHoldingsByTicker(String ticker) {
        return holdingsRepo.findByTicker(ticker);
    }

    public myHoldings saveHolding(myHoldings holding) {
        return holdingsRepo.save(holding);
    }

    public void deleteHolding(Integer id) {
        holdingsRepo.deleteById(id);
    }




}
