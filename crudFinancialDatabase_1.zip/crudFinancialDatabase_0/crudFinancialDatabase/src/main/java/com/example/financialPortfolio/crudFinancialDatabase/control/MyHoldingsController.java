package com.example.financialPortfolio.crudFinancialDatabase.control;

import com.example.financialPortfolio.crudFinancialDatabase.dao.myHoldingsDAO;
import com.example.financialPortfolio.crudFinancialDatabase.dao.myHoldingsDAOImpl;
import com.example.financialPortfolio.crudFinancialDatabase.entity.myHoldings;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RequestMapping("/api/holdings")
@RestController
public class MyHoldingsController {

//    @Autowired
//    private myHoldingsDAOImpl myHoldingsServices;
//
//    @GetMapping("/api/holdings")
//    public List<myHoldings> getHoldings(){
//        return myHoldingsServices.getAllHoldings();
//
//    }
private myHoldingsDAO holdingsDAO;

    public MyHoldingsController(myHoldingsDAO holdingsDAO){
        this.holdingsDAO = holdingsDAO;
    }
//    @PostMapping("/holdings/{id}")
//    public myHoldings addHolding(@RequestBody myHoldings holding){
//       return holdingsDAO.save(holding);
//    }

    @Autowired
    private myHoldingsDAOImpl myHoldingsService;

    @GetMapping
    public List<myHoldings> getAllHoldings() {
        return myHoldingsService.getAllHoldings();
    }

    @GetMapping("/{id}")
    public Optional<myHoldings> getHoldingById(@PathVariable Integer id) {
        return myHoldingsService.getHoldingById(id);
    }

    @GetMapping("/ticker/{ticker}")
    public List<myHoldings> getHoldingsByTicker(@PathVariable String ticker) {
        return myHoldingsService.getHoldingsByTicker(ticker);
    }

    @PostMapping
    public myHoldings createHolding(@RequestBody myHoldings myHoldings) {
        return myHoldingsService.saveHolding(myHoldings);
    }

    @PutMapping("/{id}")
    public myHoldings updateHolding(@PathVariable Integer id, @RequestBody myHoldings myHoldings) {
        myHoldings.setId(id);
        return myHoldingsService.saveHolding(myHoldings);
    }

    @DeleteMapping("/{id}")
    public void deleteHolding(@PathVariable Integer id) {
        myHoldingsService.deleteHolding(id);
    }


}
