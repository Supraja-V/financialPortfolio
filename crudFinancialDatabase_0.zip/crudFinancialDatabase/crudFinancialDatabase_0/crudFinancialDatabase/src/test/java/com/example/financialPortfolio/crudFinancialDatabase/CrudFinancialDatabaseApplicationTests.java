package com.example.financialPortfolio.crudFinancialDatabase;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudFinancialDatabaseApplicationTests {

	@Test
	void contextLoads() {
	}

}
