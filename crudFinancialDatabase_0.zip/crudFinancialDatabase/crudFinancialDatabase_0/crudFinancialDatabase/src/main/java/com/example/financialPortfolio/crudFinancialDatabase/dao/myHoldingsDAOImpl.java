package com.example.financialPortfolio.crudFinancialDatabase.dao;

import com.example.financialPortfolio.crudFinancialDatabase.entity.myHoldings;
import com.example.financialPortfolio.crudFinancialDatabase.repository.holdingsRepository;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class myHoldingsDAOImpl implements myHoldingsDAO{

//    public myHoldingsDAOImpl(holdingsRepository holdingsRepo){
//        this.holdingsRepo = holdingsRepo;
//    }

    @Autowired
    private holdingsRepository myHoldingsRepo;
    @Override
    public List<myHoldings> getAllHoldings() {
        return myHoldingsRepo.findAll();
    }
}
