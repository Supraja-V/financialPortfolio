package com.example.financialPortfolio.crudFinancialDatabase.control;

import com.example.financialPortfolio.crudFinancialDatabase.dao.myTransactionsDAOImpl;
import com.example.financialPortfolio.crudFinancialDatabase.entity.myTransactions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class MyTransactionsController {
    @Autowired
    private myTransactionsDAOImpl myTransactionsService;

    @GetMapping("/api/transactions/{ticker}")
    public List<myTransactions> getTransactions(@PathVariable String ticker) {
        return myTransactionsService.getTransactionsByTicker(ticker);
    }
}
