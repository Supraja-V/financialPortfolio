package com.example.financialPortfolio.crudFinancialDatabase;

import com.example.financialPortfolio.crudFinancialDatabase.dao.myHoldingsDAO;
import com.example.financialPortfolio.crudFinancialDatabase.entity.myHoldings;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class CrudFinancialDatabaseApplication {

	public static void main(String[] args) {
		SpringApplication.run(CrudFinancialDatabaseApplication.class, args);
	}

	@Bean
	public CommandLineRunner commandLineRunner(myHoldingsDAO holdings){

		return runner-> {
			System.out.println("Financial Portfolio");
			//createHolding(holdings);
		};

	}

	private void createHolding(myHoldingsDAO holdings){
//		System.out.println("Saving into table for Holdings");
//		myHoldings tempHolding = new myHoldings("AMZN","Amazon",10,"Stocks");
//		System.out.println("Saving the holding");
//		holdings.save(tempHolding);
//		System.out.println("Saved holdings Generated ID: "+tempHolding.getId());
	}

}
