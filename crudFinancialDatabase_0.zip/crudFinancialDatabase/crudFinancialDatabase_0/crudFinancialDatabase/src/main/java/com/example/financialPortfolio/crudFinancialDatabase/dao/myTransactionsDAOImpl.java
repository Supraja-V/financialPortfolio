package com.example.financialPortfolio.crudFinancialDatabase.dao;

import com.example.financialPortfolio.crudFinancialDatabase.entity.myTransactions;
import com.example.financialPortfolio.crudFinancialDatabase.repository.transactionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class myTransactionsDAOImpl implements myTransactionsDAO {

    @Autowired
    private transactionRepository myTransactionRepository;

    @Override
    public List<myTransactions> getTransactionsByTicker(String ticker) {
        return myTransactionRepository.findByTicker(ticker);
    }
}
