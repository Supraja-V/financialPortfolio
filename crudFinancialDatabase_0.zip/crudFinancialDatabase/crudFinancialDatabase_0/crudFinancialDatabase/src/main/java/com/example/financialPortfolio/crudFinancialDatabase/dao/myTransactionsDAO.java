package com.example.financialPortfolio.crudFinancialDatabase.dao;

import com.example.financialPortfolio.crudFinancialDatabase.entity.myTransactions;

import java.util.List;

public interface myTransactionsDAO {
    public List<myTransactions> getTransactionsByTicker(String ticker);
}
