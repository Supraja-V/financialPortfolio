package com.example.financialPortfolio.crudFinancialDatabase.entity;

import jakarta.persistence.*;

import java.util.Date;

@Entity
@Table(name = "mytransactions")
public class myTransactions {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)

    private Integer transaction_id;

    private Date transaction_date;

    private String ticker;

    public myTransactions() {
    }

    public myTransactions(Date transaction_date, String ticker, String type, Integer volume, Float invested_amount, Float per_share_price) {
        this.transaction_date = transaction_date;
        this.ticker = ticker;
        this.type = type;
        this.volume = volume;
        this.invested_amount = invested_amount;
        this.per_share_price = per_share_price;
    }

    @Override
    public String toString() {
        return "myTransactions{" +
                "transaction_id=" + transaction_id +
                ", transaction_date=" + transaction_date +
                ", ticker='" + ticker + '\'' +
                ", type='" + type + '\'' +
                ", volume=" + volume +
                ", invested_amount=" + invested_amount +
                ", per_share_price=" + per_share_price +
                '}';
    }

    private String type;

    private Integer volume;

    private Float invested_amount;

    private Float per_share_price;

    public Integer getTransaction_id() {
        return transaction_id;
    }

    public void setTransaction_id(Integer transaction_id) {
        this.transaction_id = transaction_id;
    }

    public Date getTransaction_date() {
        return transaction_date;
    }

    public void setTransaction_date(Date transaction_date) {
        this.transaction_date = transaction_date;
    }

    public String getTicker() {
        return ticker;
    }

    public void setTicker(String ticker) {
        this.ticker = ticker;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Integer getVolume() {
        return volume;
    }

    public void setVolume(Integer volume) {
        this.volume = volume;
    }

    public Float getInvested_amount() {
        return invested_amount;
    }

    public void setInvested_amount(Float invested_amount) {
        this.invested_amount = invested_amount;
    }

    public Float getPer_share_price() {
        return per_share_price;
    }

    public void setPer_share_price(Float per_share_price) {
        this.per_share_price = per_share_price;
    }
}

