package com.example.financialPortfolio.crudFinancialDatabase.control;

import com.example.financialPortfolio.crudFinancialDatabase.dao.myHoldingsDAO;
import com.example.financialPortfolio.crudFinancialDatabase.entity.myHoldings;
import com.example.financialPortfolio.crudFinancialDatabase.repository.holdingsRepository;
import org.springframework.web.bind.annotation.*;

@CrossOrigin
@RestController
public class holdingsController {

    private myHoldingsDAO holdingsDAO;

    public holdingsController(myHoldingsDAO holdingsDAO){
        this.holdingsDAO = holdingsDAO;
    }
//    @PostMapping("/holdings/{id}")
//    public myHoldings addHolding(@RequestBody myHoldings holding){
//       return holdingsDAO.save(holding);
//    }

}


