package com.example.financialPortfolio.crudFinancialDatabase.repository;

import com.example.financialPortfolio.crudFinancialDatabase.entity.myTransactions;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface transactionRepository extends JpaRepository<myTransactions,Integer> {
    List<myTransactions> findByTicker(String ticker);
}
