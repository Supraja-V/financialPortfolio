package com.example.financialPortfolio.crudFinancialDatabase.control;

import com.example.financialPortfolio.crudFinancialDatabase.dao.myHoldingsDAOImpl;
import com.example.financialPortfolio.crudFinancialDatabase.entity.myHoldings;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class MyHoldingsController {

    @Autowired
    private myHoldingsDAOImpl myHoldingsServices;

    @GetMapping("/api/holdings")
    public List<myHoldings> getHoldings(){
        return myHoldingsServices.getAllHoldings();

    }


}
