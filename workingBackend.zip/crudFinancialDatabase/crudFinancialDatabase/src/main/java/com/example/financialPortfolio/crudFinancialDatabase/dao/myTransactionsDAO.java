package com.example.financialPortfolio.crudFinancialDatabase.dao;

public interface myTransactionsDAO {

}
