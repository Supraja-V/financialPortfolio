package com.example.financialPortfolio.crudFinancialDatabase.dao;

import com.example.financialPortfolio.crudFinancialDatabase.entity.myHoldings;
import com.example.financialPortfolio.crudFinancialDatabase.repository.holdingsRepository;
import jakarta.transaction.Transactional;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class myHoldingsDAOImpl implements myHoldingsDAO{
    private holdingsRepository holdingsRepo;

    public myHoldingsDAOImpl(holdingsRepository holdingsRepo){
        this.holdingsRepo = holdingsRepo;
    }
    @Override
    @Transactional
    public myHoldings save(myHoldings holding) {
        holdingsRepo.save(holding);
        return holding;
    }



}
