package com.example.financialPortfolio.crudFinancialDatabase.entity;

import jakarta.persistence.*;

import java.util.Date;

@Entity
@Table(name = "mytransactions")
public class myTransactions {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)

    private Integer transactionId;

    private Date transactionDate;

    public Integer getTransactionId() {
        return transactionId;
    }

    @Override
    public String toString() {
        return "myTransactions{" +
                "transactionId=" + transactionId +
                ", transactionDate=" + transactionDate +
                ", buyOrSell='" + buyOrSell + '\'' +
                ", transactionPrice=" + transactionPrice +
                ", volume=" + volume +
                '}';
    }

    public myTransactions(Integer id_fk, Date transactionDate, String buyOrSell, Float transactionPrice, Integer volume) {
        this.transactionDate = transactionDate;
        this.buyOrSell = buyOrSell;
        this.transactionPrice = transactionPrice;
        this.volume = volume;
    }

    public myTransactions(){

    }

    public void setTransactionId(Integer transactionId) {
        this.transactionId = transactionId;
    }


    public Date getTransactionDate() {
        return transactionDate;
    }

    public void setTransactionDate(Date transactionDate) {
        this.transactionDate = transactionDate;
    }

    public String getBuyOrSell() {
        return buyOrSell;
    }

    public void setBuyOrSell(String buyOrSell) {
        this.buyOrSell = buyOrSell;
    }

    public Float getTransactionPrice() {
        return transactionPrice;
    }

    public void setTransactionPrice(Float transactionPrice) {
        this.transactionPrice = transactionPrice;
    }

    public Integer getVolume() {
        return volume;
    }

    public void setVolume(Integer volume) {
        this.volume = volume;
    }

    private String buyOrSell;

    private Float transactionPrice;

    private Integer volume;



}

